<?php
//Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
define('PAYTM_MERCHANT_KEY', 'bDsFOWJLzC9Rkudw'); 
// define('PAYTM_MERCHANT_KEY', '&bF57%RAWrF2vbn3'); 
?>
